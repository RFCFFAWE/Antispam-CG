package andrey.antispam_cg;

import andrey.antispam_cg.CMD.CMD;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

public final class Antispam_CG extends JavaPlugin implements Listener {

    private final Map<Player, Long> chatCooldown = new HashMap<>();
    private int cooldownSeconds;
    private final Logger log = getLogger();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadConfigValues();

        log.info("Plugin enabled!");

        validateCooldown();

        getCommand("antispamcg").setExecutor(new CMD());
        getServer().getPluginManager().registerEvents(this, this);
    }

    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        long currentTime = System.currentTimeMillis();

        if (player.hasPermission("antispamcg.bypass.delay")) {
            if (!getConfig().getBoolean("enable-for-players-with-op") || !player.isOp()) {
                return;
            }
        }

        Long lastChatTime = chatCooldown.get(player);
        if (lastChatTime != null && currentTime - lastChatTime < cooldownSeconds * 1000) {
            event.setCancelled(true);

            long timeLeft = getTimeLeft(lastChatTime, currentTime);
            String message = hexToColor(getConfig().getString("delay-message"));
            player.sendMessage(replaceSecondsPlaceholder(message, timeLeft));
        } else {
            chatCooldown.put(player, currentTime);
        }
    }

    @Override
    public void onDisable() {
        log.info("Plugin disabled!");
    }

    private String hexToColor(String message) {
        return message.replaceAll("(?i)&([0-9a-f]{6})", "§x§$1§$2§$3§$4§$5§$6")
                .replace("&", "§");
    }

    private void validateCooldown() {
        if (cooldownSeconds < 0) {
            cooldownSeconds = 3;
            getConfig().set("delay-seconds", 3);
            saveConfig();
            log.info("\u001B[91m" + "The delay cannot be less than 0! The delay has been changed to 3." + "\u001B[0m");
        }
    }

    public void loadConfigValues() {
        this.cooldownSeconds = getConfig().getInt("delay-seconds", 3);
    }

    private long getTimeLeft(Long lastChatTime, long currentTime) {
        return (cooldownSeconds * 1000 - (currentTime - lastChatTime)) / 1000;
    }

    private String replaceSecondsPlaceholder(String message, long secondsLeft) {
        return message.replace("<seconds>", String.valueOf(secondsLeft));
    }
}
