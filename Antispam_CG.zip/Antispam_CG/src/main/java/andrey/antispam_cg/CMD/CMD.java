package andrey.antispam_cg.CMD;

import andrey.antispam_cg.Antispam_CG;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class CMD implements CommandExecutor, TabCompleter {

    private final Logger log = Antispam_CG.getPlugin(Antispam_CG.class).getLogger();
    private final Antispam_CG plugin = Antispam_CG.getPlugin(Antispam_CG.class);

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            if (sender instanceof ConsoleCommandSender || (sender instanceof Player && ((Player) sender).isOp())) {
                performReload(sender);
            } else {
                sender.sendMessage(hexToColor(plugin.getConfig().getString("no-permission")));
            }
            return true;
        }

        sender.sendMessage(hexToColor(plugin.getConfig().getString("wrong-argument")));
        return true;
    }

    private void performReload(CommandSender sender) {
        Antispam_CG plugin = Antispam_CG.getPlugin(Antispam_CG.class);
        plugin.reloadConfig();

        if (sender instanceof Player) {
            sender.sendMessage(hexToColor(plugin.getConfig().getString("config-reloaded")));
        }

        log.info("\u001B[92m" + "Configuration reloaded!" + "\u001B[0m");

        int delaySeconds = plugin.getConfig().getInt("delay-seconds");
        if (delaySeconds < 0) {
            plugin.getConfig().set("delay-seconds", 3);
            plugin.saveConfig();
            sender.sendMessage("§cThe delay cannot be less than 0! The delay has been changed to 3.");
            log.info("\u001B[91m" + "The delay cannot be less than 0! The delay has been changed to 3." + "\u001B[0m");
        }

        plugin.loadConfigValues();
    }

    private String hexToColor(String message) {
        return message.replaceAll("(?i)&([0-9a-f]{6})", "§x§$1§$2§$3§$4§$5§$6")
                .replace("&", "§");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1 && "reload".startsWith(args[0].toLowerCase())) {
            completions.add("reload");
        }
        return completions;
    }
}
